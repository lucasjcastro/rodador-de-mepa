#include "tokentype.h"

tokentype::tokentype()
{
}

tokentype::~tokentype()
{
}
